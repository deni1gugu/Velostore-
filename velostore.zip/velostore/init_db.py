"""
Инициализация базы данных.
Запусти один раз перед первым стартом приложения:
    python init_db.py
"""
import sqlite3, os

DB_PATH  = os.path.join(os.path.dirname(__file__), 'bicycle_store.db')
SQL_PATH = os.path.join(os.path.dirname(__file__), 'init_db.sql')

if os.path.exists(DB_PATH):
    ans = input(f'База {DB_PATH} уже существует. Пересоздать? [y/N]: ')
    if ans.strip().lower() != 'y':
        print('Отменено.')
        exit()
    os.remove(DB_PATH)

conn = sqlite3.connect(DB_PATH)
with open(SQL_PATH, encoding='utf-8') as f:
    conn.executescript(f.read())
conn.close()
print(f'✅  База данных создана: {DB_PATH}')
print('   Логины: admin / manager1 / client1  |  Пароль для всех: password123')
