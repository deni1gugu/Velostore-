import os
import hashlib
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
import sqlite3

app = Flask(__name__)
app.secret_key = 'velostore-secret-2026'

DB_PATH = os.path.join(os.path.dirname(__file__), 'bicycle_store.db')


# ── DB helpers ────────────────────────────────────────────────────────────────
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db:
        db.close()

def query(sql, args=(), one=False):
    cur = get_db().execute(sql, args)
    rv = cur.fetchall()
    return (rv[0] if rv else None) if one else rv

def execute(sql, args=()):
    db = get_db()
    cur = db.execute(sql, args)
    db.commit()
    return cur.lastrowid

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()


# ── Auth helpers ──────────────────────────────────────────────────────────────
def current_role():
    return session.get('role', 'guest')

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходима авторизация', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapped

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if current_role() not in roles:
                flash('Недостаточно прав', 'danger')
                return redirect(url_for('products_list'))
            return f(*args, **kwargs)
        return wrapped
    return decorator


# ── Auth routes ───────────────────────────────────────────────────────────────
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'guest':
            session.clear()
            session['role'] = 'guest'
            return redirect(url_for('products_list'))
        username = request.form['username'].strip()
        password = request.form['password']
        user = query(
            '''SELECT u.user_id, u.username, u.full_name, u.is_active, r.role_name
               FROM users u JOIN roles r ON r.role_id = u.role_id
               WHERE u.username = ? AND u.password_hash = ?''',
            (username, hash_pw(password)), one=True
        )
        if user and user['is_active']:
            session.clear()
            session['user_id']   = user['user_id']
            session['username']  = user['username']
            session['full_name'] = user['full_name']
            session['role']      = user['role_name']
            flash(f'Добро пожаловать, {user["full_name"]}!', 'success')
            return redirect(url_for('products_list'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# ── Products ──────────────────────────────────────────────────────────────────
@app.route('/products')
def products_list():
    role = current_role()
    search = request.args.get('q', '').strip()
    category_id = request.args.get('category', '')
    sort = request.args.get('sort', 'product_name')
    order = request.args.get('order', 'asc')

    allowed_sorts = {'product_name', 'price', 'brand', 'article'}
    if sort not in allowed_sorts:
        sort = 'product_name'
    order_sql = 'ASC' if order == 'asc' else 'DESC'

    sql = '''SELECT p.product_id, p.product_name, p.article, p.price,
                    p.brand, p.color, p.description,
                    c.category_name,
                    COALESCE(SUM(s.quantity), 0) AS total_stock
             FROM products p
             JOIN categories c ON c.category_id = p.category_id
             LEFT JOIN stock s ON s.product_id = p.product_id
             WHERE p.is_active = 1'''
    args = []
    if role in ('manager', 'admin') and search:
        sql += ' AND (p.product_name LIKE ? OR p.article LIKE ? OR p.brand LIKE ?)'
        args += [f'%{search}%'] * 3
    if role in ('manager', 'admin') and category_id:
        sql += ' AND p.category_id = ?'
        args.append(category_id)
    sql += f' GROUP BY p.product_id ORDER BY p.{sort} {order_sql}'

    products = query(sql, args)
    categories = query('SELECT category_id, category_name FROM categories ORDER BY category_name')
    return render_template('products.html', products=products, categories=categories,
                           search=search, category_id=category_id, sort=sort, order=order, role=role)

@app.route('/products/add', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def product_add():
    categories = query('SELECT category_id, category_name FROM categories ORDER BY category_name')
    suppliers  = query('SELECT supplier_id, company_name FROM suppliers ORDER BY company_name')
    if request.method == 'POST':
        f = request.form
        pid = execute(
            '''INSERT INTO products (product_name,article,category_id,supplier_id,
               description,price,weight_kg,color,brand)
               VALUES (?,?,?,?,?,?,?,?,?)''',
            (f['product_name'], f['article'], f['category_id'],
             f.get('supplier_id') or None, f.get('description'),
             float(f['price']), f.get('weight_kg') or None,
             f.get('color'), f.get('brand'))
        )
        flash('Товар добавлен', 'success')
        return redirect(url_for('products_list'))
    return render_template('product_form.html', product=None, categories=categories, suppliers=suppliers)

@app.route('/products/<int:pid>/edit', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def product_edit(pid):
    product    = query('SELECT * FROM products WHERE product_id=?', (pid,), one=True)
    categories = query('SELECT category_id, category_name FROM categories ORDER BY category_name')
    suppliers  = query('SELECT supplier_id, company_name FROM suppliers ORDER BY company_name')
    if not product:
        flash('Товар не найден', 'danger')
        return redirect(url_for('products_list'))
    if request.method == 'POST':
        f = request.form
        execute(
            '''UPDATE products SET product_name=?,article=?,category_id=?,supplier_id=?,
               description=?,price=?,weight_kg=?,color=?,brand=? WHERE product_id=?''',
            (f['product_name'], f['article'], f['category_id'],
             f.get('supplier_id') or None, f.get('description'),
             float(f['price']), f.get('weight_kg') or None,
             f.get('color'), f.get('brand'), pid)
        )
        flash('Товар обновлён', 'success')
        return redirect(url_for('products_list'))
    return render_template('product_form.html', product=product, categories=categories, suppliers=suppliers)

@app.route('/products/<int:pid>/delete', methods=['POST'])
@login_required
@role_required('admin')
def product_delete(pid):
    execute('UPDATE products SET is_active=0 WHERE product_id=?', (pid,))
    flash('Товар удалён', 'success')
    return redirect(url_for('products_list'))


# ── Orders ────────────────────────────────────────────────────────────────────
@app.route('/orders')
@login_required
@role_required('manager', 'admin')
def orders_list():
    orders = query('''
        SELECT o.order_id, o.order_number, o.customer_name, o.customer_phone,
               o.total_amount, o.created_at, os.status_name, w.warehouse_name
        FROM orders o
        JOIN order_statuses os ON os.status_id = o.status_id
        LEFT JOIN warehouses w ON w.warehouse_id = o.warehouse_id
        ORDER BY o.created_at DESC''')
    return render_template('orders.html', orders=orders, role=current_role())

@app.route('/orders/<int:oid>')
@login_required
@role_required('manager', 'admin')
def order_detail(oid):
    order = query('''
        SELECT o.*, os.status_name, w.warehouse_name
        FROM orders o
        JOIN order_statuses os ON os.status_id = o.status_id
        LEFT JOIN warehouses w ON w.warehouse_id = o.warehouse_id
        WHERE o.order_id=?''', (oid,), one=True)
    if not order:
        flash('Заказ не найден', 'danger')
        return redirect(url_for('orders_list'))
    items = query('''
        SELECT oi.*, p.product_name, p.article,
               ROUND(oi.quantity * oi.unit_price * (1 - oi.discount/100.0), 2) AS line_total
        FROM order_items oi JOIN products p ON p.product_id=oi.product_id
        WHERE oi.order_id=?''', (oid,))
    return render_template('order_detail.html', order=order, items=items, role=current_role())

@app.route('/orders/add', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def order_add():
    statuses   = query('SELECT status_id, status_name FROM order_statuses')
    warehouses = query('SELECT warehouse_id, warehouse_name FROM warehouses')
    products   = query('SELECT product_id, product_name, price FROM products WHERE is_active=1 ORDER BY product_name')
    if request.method == 'POST':
        f = request.form
        import datetime, random
        order_number = f.get('order_number') or f'ORD-{datetime.date.today().year}-{random.randint(1000,9999)}'
        oid = execute(
            '''INSERT INTO orders (order_number,user_id,status_id,warehouse_id,
               customer_name,customer_phone,customer_email,delivery_address,total_amount,comment)
               VALUES (?,?,?,?,?,?,?,?,?,?)''',
            (order_number, session.get('user_id'), f['status_id'],
             f.get('warehouse_id') or None, f['customer_name'],
             f.get('customer_phone'), f.get('customer_email'),
             f.get('delivery_address'), 0, f.get('comment'))
        )
        # items
        total = 0
        pids = request.form.getlist('product_id[]')
        qtys = request.form.getlist('quantity[]')
        prices = request.form.getlist('unit_price[]')
        for pid, qty, price in zip(pids, qtys, prices):
            if pid and qty and int(qty) > 0:
                execute('INSERT INTO order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)',
                        (oid, int(pid), int(qty), float(price)))
                total += int(qty) * float(price)
        execute('UPDATE orders SET total_amount=? WHERE order_id=?', (total, oid))
        flash('Заказ создан', 'success')
        return redirect(url_for('orders_list'))
    return render_template('order_form.html', order=None, statuses=statuses,
                           warehouses=warehouses, products=products)

@app.route('/orders/<int:oid>/edit', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def order_edit(oid):
    order      = query('SELECT * FROM orders WHERE order_id=?', (oid,), one=True)
    statuses   = query('SELECT status_id, status_name FROM order_statuses')
    warehouses = query('SELECT warehouse_id, warehouse_name FROM warehouses')
    products   = query('SELECT product_id, product_name, price FROM products WHERE is_active=1 ORDER BY product_name')
    items      = query('SELECT * FROM order_items WHERE order_id=?', (oid,))
    if not order:
        flash('Заказ не найден', 'danger')
        return redirect(url_for('orders_list'))
    if request.method == 'POST':
        f = request.form
        execute(
            '''UPDATE orders SET status_id=?,warehouse_id=?,customer_name=?,
               customer_phone=?,customer_email=?,delivery_address=?,comment=? WHERE order_id=?''',
            (f['status_id'], f.get('warehouse_id') or None, f['customer_name'],
             f.get('customer_phone'), f.get('customer_email'),
             f.get('delivery_address'), f.get('comment'), oid)
        )
        execute('DELETE FROM order_items WHERE order_id=?', (oid,))
        total = 0
        pids   = request.form.getlist('product_id[]')
        qtys   = request.form.getlist('quantity[]')
        prices = request.form.getlist('unit_price[]')
        for pid, qty, price in zip(pids, qtys, prices):
            if pid and qty and int(qty) > 0:
                execute('INSERT INTO order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)',
                        (oid, int(pid), int(qty), float(price)))
                total += int(qty) * float(price)
        execute('UPDATE orders SET total_amount=? WHERE order_id=?', (total, oid))
        flash('Заказ обновлён', 'success')
        return redirect(url_for('orders_list'))
    return render_template('order_form.html', order=order, statuses=statuses,
                           warehouses=warehouses, products=products, items=items)

@app.route('/orders/<int:oid>/delete', methods=['POST'])
@login_required
@role_required('admin')
def order_delete(oid):
    execute('DELETE FROM orders WHERE order_id=?', (oid,))
    flash('Заказ удалён', 'success')
    return redirect(url_for('orders_list'))


if __name__ == '__main__':
    app.run(debug=True)
