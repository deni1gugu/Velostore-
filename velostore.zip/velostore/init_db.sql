-- ============================================================
-- База данных: Магазин велосипедов
-- СУБД: SQLite
-- Нормальная форма: 3НФ
-- Автор: ИСП23В
-- ============================================================

PRAGMA foreign_keys = ON;

-- ------------------------------------------------------------
-- Таблица: roles (Роли пользователей)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    role_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    role_name TEXT    NOT NULL UNIQUE  -- 'guest', 'client', 'manager', 'admin'
);

-- ------------------------------------------------------------
-- Таблица: users (Пользователи)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    full_name     TEXT    NOT NULL,
    email         TEXT             UNIQUE,
    phone         TEXT,
    role_id       INTEGER NOT NULL REFERENCES roles(role_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- ------------------------------------------------------------
-- Таблица: categories (Категории товаров)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    category_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name TEXT    NOT NULL UNIQUE,
    description   TEXT
);

-- ------------------------------------------------------------
-- Таблица: suppliers (Поставщики)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    company_name  TEXT    NOT NULL,
    contact_name  TEXT,
    phone         TEXT,
    email         TEXT,
    address       TEXT
);

-- ------------------------------------------------------------
-- Таблица: warehouses (Склады)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS warehouses (
    warehouse_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    warehouse_name TEXT    NOT NULL,
    address        TEXT    NOT NULL,
    phone          TEXT
);

-- ------------------------------------------------------------
-- Таблица: products (Товары)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    product_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    product_name  TEXT    NOT NULL,
    article       TEXT    NOT NULL UNIQUE,   -- артикул
    category_id   INTEGER NOT NULL REFERENCES categories(category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    supplier_id   INTEGER          REFERENCES suppliers(supplier_id)  ON UPDATE CASCADE ON DELETE SET NULL,
    description   TEXT,
    price         REAL    NOT NULL CHECK (price >= 0),
    weight_kg     REAL             CHECK (weight_kg >= 0),
    color         TEXT,
    brand         TEXT,
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------------------------------------
-- Таблица: stock (Остатки товаров на складах)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stock (
    stock_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id    INTEGER NOT NULL REFERENCES products(product_id)   ON UPDATE CASCADE ON DELETE CASCADE,
    warehouse_id  INTEGER NOT NULL REFERENCES warehouses(warehouse_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    quantity      INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    min_quantity  INTEGER NOT NULL DEFAULT 0 CHECK (min_quantity >= 0),  -- минимальный остаток
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (product_id, warehouse_id)
);

-- ------------------------------------------------------------
-- Таблица: order_statuses (Статусы заказов)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_statuses (
    status_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    status_name TEXT    NOT NULL UNIQUE  -- 'new', 'confirmed', 'assembled', 'shipped', 'delivered', 'cancelled'
);

-- ------------------------------------------------------------
-- Таблица: orders (Заказы)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    order_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number  TEXT    NOT NULL UNIQUE,
    user_id       INTEGER          REFERENCES users(user_id)          ON UPDATE CASCADE ON DELETE SET NULL,
    status_id     INTEGER NOT NULL REFERENCES order_statuses(status_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    warehouse_id  INTEGER          REFERENCES warehouses(warehouse_id) ON UPDATE CASCADE ON DELETE SET NULL,
    customer_name TEXT    NOT NULL,
    customer_phone TEXT,
    customer_email TEXT,
    delivery_address TEXT,
    total_amount  REAL    NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    comment       TEXT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------------------------------------
-- Таблица: order_items (Позиции заказа)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    item_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL REFERENCES orders(order_id)    ON UPDATE CASCADE ON DELETE CASCADE,
    product_id    INTEGER NOT NULL REFERENCES products(product_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    unit_price    REAL    NOT NULL CHECK (unit_price >= 0),  -- цена на момент заказа
    discount      REAL    NOT NULL DEFAULT 0 CHECK (discount BETWEEN 0 AND 100),
    UNIQUE (order_id, product_id)
);

-- ============================================================
-- ИНДЕКСЫ
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_supplier  ON products(supplier_id);
CREATE INDEX IF NOT EXISTS idx_products_article   ON products(article);
CREATE INDEX IF NOT EXISTS idx_stock_product      ON stock(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_warehouse    ON stock(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_orders_user        ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status      ON orders(status_id);
CREATE INDEX IF NOT EXISTS idx_orders_number      ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_order_items_order  ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_users_role         ON users(role_id);

-- ============================================================
-- НАЧАЛЬНЫЕ ДАННЫЕ (справочники)
-- ============================================================

-- Роли
INSERT INTO roles (role_name) VALUES
    ('guest'),
    ('client'),
    ('manager'),
    ('admin');

-- Статусы заказов
INSERT INTO order_statuses (status_name) VALUES
    ('new'),
    ('confirmed'),
    ('assembled'),
    ('shipped'),
    ('delivered'),
    ('cancelled');

-- Категории товаров
INSERT INTO categories (category_name, description) VALUES
    ('Велосипеды горные',    'Горные велосипеды для бездорожья'),
    ('Велосипеды шоссейные', 'Шоссейные велосипеды для асфальтированных дорог'),
    ('Велосипеды городские', 'Городские велосипеды для повседневного использования'),
    ('Велосипеды детские',   'Велосипеды для детей'),
    ('Аксессуары',           'Шлемы, перчатки, замки, фары и прочее'),
    ('Запчасти',             'Колёса, тормоза, вилки, трансмиссия'),
    ('Одежда',               'Велосипедная одежда и экипировка');

-- Склады
INSERT INTO warehouses (warehouse_name, address, phone) VALUES
    ('Главный склад',    'г. Москва, ул. Складская, д. 1',   '+7(495)000-00-01'),
    ('Склад №2',         'г. Москва, ул. Промышленная, д. 5', '+7(495)000-00-02'),
    ('Региональный склад','г. Санкт-Петербург, пр. Заводской, д. 10', '+7(812)000-00-01');

-- Поставщики
INSERT INTO suppliers (company_name, contact_name, phone, email, address) VALUES
    ('ВелоОпт ООО',       'Иванов Пётр Сергеевич', '+7(495)111-11-11', 'ivanov@veloopt.ru',   'г. Москва, ул. Торговая, д. 3'),
    ('CycleWorld Ltd',    'John Smith',             '+44-20-1234-5678', 'john@cycleworld.com', 'London, UK'),
    ('БайкПро ЗАО',       'Сидорова Анна',          '+7(812)222-22-22', 'sidorova@bikepro.ru', 'г. СПб, пр. Невский, д. 100');

-- Пользователи (пароль — хэш строки "password123", здесь заглушка)
INSERT INTO users (username, password_hash, full_name, email, phone, role_id) VALUES
    ('admin',    'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Администратор Системы',  'admin@velostore.ru',   '+7(495)000-00-00', 4),
    ('manager1', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Петров Алексей Иванович','manager1@velostore.ru','+7(495)000-00-11', 3),
    ('client1',  'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Козлов Дмитрий Юрьевич', 'client1@mail.ru',      '+7(916)100-00-01', 2);

-- Товары
INSERT INTO products (product_name, article, category_id, supplier_id, description, price, weight_kg, color, brand) VALUES
    ('Велосипед горный Stels Navigator 500 MD 26"', 'STL-NAV500-BLK', 1, 1, 'Горный велосипед с алюминиевой рамой, 21 скорость', 18990.00, 14.5, 'Чёрный',  'Stels'),
    ('Велосипед горный Trek Marlin 5 29"',           'TRK-MAR5-BLU',  1, 2, 'Горный велосипед с гидравлическими тормозами',        54900.00, 13.8, 'Синий',   'Trek'),
    ('Велосипед шоссейный Merida Scultura 100',      'MRD-SCL100-WHT',2, 2, 'Шоссейный велосипед, карбоновая вилка',               62500.00, 9.2,  'Белый',   'Merida'),
    ('Велосипед городской Stels Navigator 300 Lady', 'STL-NAV300-RED',3, 1, 'Городской велосипед, женская рама, 7 скоростей',      12500.00, 13.0, 'Красный', 'Stels'),
    ('Велосипед детский Stels Jet 12"',              'STL-JET12-PNK', 4, 1, 'Детский велосипед с боковыми колёсами',                5900.00,  7.5, 'Розовый', 'Stels'),
    ('Шлем велосипедный Bell Tracker R',             'BLL-TRK-R-BLK', 5, 3, 'Защитный шлем, размер M',                             3490.00,  0.32,'Чёрный',  'Bell'),
    ('Замок велосипедный Kryptonite Evolution',       'KRP-EVO-STD',   5, 3, 'Надёжный цепной замок',                               2890.00,  1.4, NULL,      'Kryptonite'),
    ('Покрышка Continental Cross King 29x2.2',        'CNT-CK-29-22',  6, 2, 'Универсальная покрышка для горного велосипеда',       2150.00,  0.78,NULL,      'Continental'),
    ('Джерси велосипедное Craft Core Endure',         'CRF-END-JRS-L', 7, 3, 'Функциональное джерси, размер L',                    4200.00,  0.19,'Синий',   'Craft');

-- Остатки на складах
INSERT INTO stock (product_id, warehouse_id, quantity, min_quantity) VALUES
    (1, 1, 15, 3),
    (1, 2,  4, 2),
    (2, 1,  6, 2),
    (3, 1,  3, 1),
    (4, 1, 12, 3),
    (4, 3,  7, 2),
    (5, 1, 20, 5),
    (5, 3, 10, 5),
    (6, 1, 30, 5),
    (6, 2, 15, 5),
    (7, 1, 22, 5),
    (8, 1, 50, 10),
    (8, 2, 25, 10),
    (9, 1, 18, 5);

-- Заказы
INSERT INTO orders (order_number, user_id, status_id, warehouse_id, customer_name, customer_phone, customer_email, delivery_address, total_amount, comment) VALUES
    ('ORD-2026-0001', 3, 5, 1, 'Козлов Дмитрий Юрьевич', '+7(916)100-00-01', 'client1@mail.ru', 'г. Москва, ул. Ленина, д. 5, кв. 10', 18990.00, NULL),
    ('ORD-2026-0002', 3, 2, 1, 'Козлов Дмитрий Юрьевич', '+7(916)100-00-01', 'client1@mail.ru', 'г. Москва, ул. Ленина, д. 5, кв. 10', 65390.00, 'Срочный заказ'),
    ('ORD-2026-0003', NULL, 1, 2, 'Смирнова Ольга',         '+7(903)200-00-02', 'smirnova@mail.ru','г. Москва, пр. Мира, д. 20, кв. 3',   12500.00, NULL);

-- Позиции заказов
INSERT INTO order_items (order_id, product_id, quantity, unit_price, discount) VALUES
    (1, 1, 1, 18990.00, 0),
    (2, 2, 1, 54900.00, 0),
    (2, 6, 1,  3490.00, 0),
    (2, 7, 1,  2890.00, 5),
    (3, 4, 1, 12500.00, 0);

-- ============================================================
-- ПРЕДСТАВЛЕНИЯ (Views) для удобства
-- ============================================================

-- Просмотр остатков товаров с деталями
CREATE VIEW IF NOT EXISTS v_stock_details AS
SELECT
    p.product_id,
    p.article,
    p.product_name,
    p.brand,
    c.category_name,
    p.price,
    w.warehouse_name,
    s.quantity,
    s.min_quantity,
    CASE WHEN s.quantity <= s.min_quantity THEN 1 ELSE 0 END AS is_low_stock
FROM stock s
JOIN products   p ON p.product_id   = s.product_id
JOIN categories c ON c.category_id  = p.category_id
JOIN warehouses w ON w.warehouse_id = s.warehouse_id
WHERE p.is_active = 1;

-- Просмотр заказов с деталями
CREATE VIEW IF NOT EXISTS v_order_details AS
SELECT
    o.order_id,
    o.order_number,
    o.customer_name,
    o.customer_phone,
    os.status_name,
    w.warehouse_name,
    o.total_amount,
    o.created_at,
    u.username AS manager_username
FROM orders o
JOIN order_statuses os ON os.status_id   = o.status_id
LEFT JOIN warehouses w ON w.warehouse_id = o.warehouse_id
LEFT JOIN users      u ON u.user_id      = o.user_id;

-- Просмотр позиций заказа с суммой
CREATE VIEW IF NOT EXISTS v_order_items_details AS
SELECT
    oi.item_id,
    oi.order_id,
    o.order_number,
    p.product_name,
    p.article,
    oi.quantity,
    oi.unit_price,
    oi.discount,
    ROUND(oi.quantity * oi.unit_price * (1 - oi.discount / 100.0), 2) AS line_total
FROM order_items oi
JOIN orders   o ON o.order_id   = oi.order_id
JOIN products p ON p.product_id = oi.product_id;
